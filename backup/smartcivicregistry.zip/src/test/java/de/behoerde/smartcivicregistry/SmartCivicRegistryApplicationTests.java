package de.behoerde.smartcivicregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartCivicRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
