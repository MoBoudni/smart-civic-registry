package de.behoerde.smartcivicregistry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartCivicRegistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartCivicRegistryApplication.class, args);
	}

}
